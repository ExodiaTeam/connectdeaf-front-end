package com.connectdeaf;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConnectDeafApplicationTests {

	@Test
	void contextLoads() {
	}

}
